Ceci est un faux disclaimer à présenter avant l'installation
