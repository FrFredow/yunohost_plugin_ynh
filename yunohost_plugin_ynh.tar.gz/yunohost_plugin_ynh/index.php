<?php
echo "Welcome to My PHP Application!";
?>
