Ceci est une fausse doc d'admin pour cette app

Le dossier d'install de l'app est `__INSTALL_DIR__`
