This is a dummy disclaimer to display after the install

The app url is <https://__DOMAIN____PATH__>

The app install dir is `__INSTALL_DIR__`

The app id is `__ID__`
