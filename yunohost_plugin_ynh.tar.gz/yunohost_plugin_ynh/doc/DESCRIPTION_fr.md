Ceci est une fausse description des fonctionalités de l'app
