This is a dummy disclaimer to display prior to the install
