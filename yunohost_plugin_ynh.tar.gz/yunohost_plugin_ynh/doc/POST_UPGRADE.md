This is a dummy disclaimer to display after upgrades
