This is a dummy description of this app features
