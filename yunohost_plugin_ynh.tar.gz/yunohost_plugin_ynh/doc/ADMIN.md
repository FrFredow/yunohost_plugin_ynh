This is a dummy admin doc for this app

The app install dir is `__INSTALL_DIR__`
